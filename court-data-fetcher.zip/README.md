## README for Court-Data Fetcher
Details as discussed.